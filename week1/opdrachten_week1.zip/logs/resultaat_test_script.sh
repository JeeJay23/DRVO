[29294.666183] Driver has been succesfully unregistered
[31628.889843] registered device
[31628.889852] Hello driver added successfully
[31628.889854] Started driver with A: 0 and B: 0
[32730.742653] Opened hello
[32730.742666] read 131072 bytes
[32730.742673] released hello
[32730.743240] Opened hello
[32730.743254] written 5 bytes
[32730.743257] released hello
