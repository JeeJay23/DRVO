#!/bin/bash

module="opdr_3_4"

cat /dev/$module

echo "test" >> /dev/$module